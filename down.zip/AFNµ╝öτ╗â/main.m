//
//  main.m
//  AFN演练
//
//  Created by jpkj on 14-3-26.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZWAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZWAppDelegate class]));
    }
}
