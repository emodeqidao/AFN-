//
//  ZWViewController.h
//  AFN演练
//
//  Created by jpkj on 14-3-26.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZWViewController : UIViewController

- (IBAction)downloadFiles:(UIButton *)sender;

@end
